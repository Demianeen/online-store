--
-- PostgreSQL database dump
--

-- Dumped from database version 15.1 (Debian 15.1-1.pgdg110+1)
-- Dumped by pg_dump version 15.1 (Debian 15.1-1.pgdg110+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: brands; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.brands (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    "createdAt" timestamp with time zone,
    "updatedAt" timestamp with time zone
);


ALTER TABLE public.brands OWNER TO postgres;

--
-- Name: brands_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.brands_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.brands_id_seq OWNER TO postgres;

--
-- Name: brands_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.brands_id_seq OWNED BY public.brands.id;


--
-- Name: cart_items; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.cart_items (
    id integer NOT NULL,
    size character varying(255) NOT NULL,
    quantity integer DEFAULT 1,
    "createdAt" timestamp with time zone,
    "updatedAt" timestamp with time zone,
    "ProductId" integer,
    "CartId" integer
);


ALTER TABLE public.cart_items OWNER TO postgres;

--
-- Name: cart_items_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.cart_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.cart_items_id_seq OWNER TO postgres;

--
-- Name: cart_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.cart_items_id_seq OWNED BY public.cart_items.id;


--
-- Name: carts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.carts (
    id integer NOT NULL,
    "createdAt" timestamp with time zone,
    "updatedAt" timestamp with time zone,
    "UserId" integer
);


ALTER TABLE public.carts OWNER TO postgres;

--
-- Name: carts_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.carts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.carts_id_seq OWNER TO postgres;

--
-- Name: carts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.carts_id_seq OWNED BY public.carts.id;


--
-- Name: categories; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.categories (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    gender character varying(255) NOT NULL,
    "createdAt" timestamp with time zone,
    "updatedAt" timestamp with time zone
);


ALTER TABLE public.categories OWNER TO postgres;

--
-- Name: categories_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.categories_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.categories_id_seq OWNER TO postgres;

--
-- Name: categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.categories_id_seq OWNED BY public.categories.id;


--
-- Name: colors; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.colors (
    id integer NOT NULL,
    hex character varying(255) NOT NULL,
    "createdAt" timestamp with time zone,
    "updatedAt" timestamp with time zone
);


ALTER TABLE public.colors OWNER TO postgres;

--
-- Name: colors_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.colors_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.colors_id_seq OWNER TO postgres;

--
-- Name: colors_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.colors_id_seq OWNED BY public.colors.id;


--
-- Name: products; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.products (
    id integer NOT NULL,
    description character varying(255) DEFAULT 0,
    price integer NOT NULL,
    gender character varying(255) NOT NULL,
    images character varying(255) NOT NULL,
    "isInStock" boolean DEFAULT true,
    sizes character varying(255) DEFAULT '["XS","S","M","L"]'::character varying,
    "createdAt" timestamp with time zone,
    "updatedAt" timestamp with time zone,
    "CategoryId" integer,
    "BrandId" integer
);


ALTER TABLE public.products OWNER TO postgres;

--
-- Name: products_colors; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.products_colors (
    "createdAt" timestamp with time zone,
    "updatedAt" timestamp with time zone,
    "ColorId" integer NOT NULL,
    "ProductId" integer NOT NULL
);


ALTER TABLE public.products_colors OWNER TO postgres;

--
-- Name: products_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.products_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.products_id_seq OWNER TO postgres;

--
-- Name: products_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.products_id_seq OWNED BY public.products.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id integer NOT NULL,
    email character varying(255) NOT NULL,
    password character varying(255),
    role character varying(255) DEFAULT 'USER'::character varying,
    "createdAt" timestamp with time zone,
    "updatedAt" timestamp with time zone
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_id_seq OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: brands id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.brands ALTER COLUMN id SET DEFAULT nextval('public.brands_id_seq'::regclass);


--
-- Name: cart_items id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cart_items ALTER COLUMN id SET DEFAULT nextval('public.cart_items_id_seq'::regclass);


--
-- Name: carts id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.carts ALTER COLUMN id SET DEFAULT nextval('public.carts_id_seq'::regclass);


--
-- Name: categories id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.categories ALTER COLUMN id SET DEFAULT nextval('public.categories_id_seq'::regclass);


--
-- Name: colors id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.colors ALTER COLUMN id SET DEFAULT nextval('public.colors_id_seq'::regclass);


--
-- Name: products id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.products ALTER COLUMN id SET DEFAULT nextval('public.products_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: brands; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.brands (id, name, "createdAt", "updatedAt") FROM stdin;
1	Awesome Jade	2023-03-04 12:53:17.83+00	2023-03-04 12:53:17.83+00
2	Cactus	2023-03-04 12:53:24.329+00	2023-03-04 12:53:24.329+00
\.


--
-- Data for Name: cart_items; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.cart_items (id, size, quantity, "createdAt", "updatedAt", "ProductId", "CartId") FROM stdin;
\.


--
-- Data for Name: carts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.carts (id, "createdAt", "updatedAt", "UserId") FROM stdin;
1	2023-02-10 16:41:20.914+00	2023-02-10 16:41:20.914+00	1
2	2023-02-14 09:35:03.884+00	2023-02-14 09:35:03.884+00	2
3	2023-02-16 18:32:17.732+00	2023-02-16 18:32:17.732+00	3
4	2023-02-24 15:38:06.224+00	2023-02-24 15:38:06.224+00	4
5	2023-03-04 12:37:35.062+00	2023-03-04 12:37:35.062+00	5
6	2023-03-04 12:42:33.306+00	2023-03-04 12:42:33.306+00	6
7	2023-03-04 13:10:54.928+00	2023-03-04 13:10:54.928+00	7
\.


--
-- Data for Name: categories; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.categories (id, name, gender, "createdAt", "updatedAt") FROM stdin;
1	Top	["WOMEN","MEN","KIDS"]	2023-03-04 12:52:43.903+00	2023-03-04 12:52:43.903+00
2	Bottom	["WOMEN","MEN","KIDS"]	2023-03-04 12:52:49.914+00	2023-03-04 12:52:49.914+00
3	Dress	["WOMEN","MEN","KIDS"]	2023-03-04 12:53:02.04+00	2023-03-04 12:53:02.04+00
\.


--
-- Data for Name: colors; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.colors (id, hex, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: products; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.products (id, description, price, gender, images, "isInStock", sizes, "createdAt", "updatedAt", "CategoryId", "BrandId") FROM stdin;
1	Find stunning women's cocktail dresses and party dresses. Stand out in lace and metallic cocktail dresses and party dresses from all your favorite brands.	349	WOMEN	["299cf421-c40d-44d5-8d85-14329653be63.webp","61079bb0-5839-4083-81af-8d9fd88410bb.webp","6195fbea-384b-4a67-95a2-833c90778adf.webp","cb9348fb-dd2d-4e81-9833-f41066ebbc8a.webp"]	t	["XS","S","M","L"]	2023-03-04 12:55:30.295+00	2023-03-04 12:55:30.295+00	1	1
2	Find stunning women's cocktail dresses and party dresses. Stand out in lace and metallic cocktail dresses and party dresses from all your favorite brands.	449	WOMEN	["1aa4ab5f-1784-4f73-9498-966078a24fc9.webp","0f6f2e43-bd68-4f14-9f67-52a44848d37e.webp","d4ca5ab0-95fe-447c-9a11-d6066175bc20.webp","d2dcaf96-8fe7-440d-b2ef-96589f72f639.webp"]	t	["XS","S","M","L"]	2023-03-04 12:56:00.422+00	2023-03-04 12:56:00.422+00	1	1
3	Find stunning women's cocktail dresses and party dresses. Stand out in lace and metallic cocktail dresses and party dresses from all your favorite brands.	429	WOMEN	["381c6acc-785c-4911-8061-96aa61571c46.webp","e8c429a2-2e6c-4141-acee-3092db6bd69d.webp","0d81f73d-6a43-4e7b-bf46-1e7ba43c93ff.webp","a95d6d31-ce20-4aa3-a792-683a6f174a66.webp"]	t	["XS","S","M","L"]	2023-03-04 12:56:18.235+00	2023-03-04 12:56:18.235+00	1	1
4	Find stunning women's cocktail dresses and party dresses. Stand out in lace and metallic cocktail dresses and party dresses from all your favorite brands.	449	WOMEN	["bd3a2080-9e18-4570-9d4c-f5e4bbd17f26.webp","3c192246-c544-4683-88ab-55e32e83d33a.webp","95c4ee12-692e-4ab9-a42a-46a6eb18e826.webp","4d934b56-d4ee-4895-8436-4ec68a1385f0.webp"]	t	["XS","S","M","L"]	2023-03-04 12:57:19.18+00	2023-03-04 12:57:19.18+00	1	1
5	Find stunning women's cocktail dresses and party dresses. Stand out in lace and metallic cocktail dresses and party dresses from all your favorite brands.	419	WOMEN	["a1fde9ce-bc0b-446d-9d20-12deffeb000c.webp","c808d63c-056c-46c9-8d95-041a9e88453b.webp","57292a57-60d9-49bb-a6aa-e07a19e7c725.webp","689caf24-b83f-4104-8247-9253b5a27531.webp"]	t	["XS","S","M","L"]	2023-03-04 12:57:33.825+00	2023-03-04 12:57:33.825+00	1	1
6	Find stunning women's cocktail dresses and party dresses. Stand out in lace and metallic cocktail dresses and party dresses from all your favorite brands.	449	WOMEN	["c6aed52e-824d-4041-bde1-b53b449e2d12.webp","522f3dd7-2d3f-4497-9eda-49fa9a711cfb.webp","ac26415a-bd84-4a45-9cb7-a01f3053e67b.webp","bce8f537-008b-441e-9237-f1f3b95311f0.webp"]	t	["XS","S","M","L"]	2023-03-04 12:57:47.927+00	2023-03-04 12:57:47.927+00	1	1
7	Find stunning women's cocktail dresses and party dresses. Stand out in lace and metallic cocktail dresses and party dresses from all your favorite brands.	449	WOMEN	["82e0362f-026e-4d92-8895-c2ffeb848642.webp","55693352-f7f7-4271-9a8a-e48a42465cc7.webp","ac3dd95f-64c1-4f90-ada9-5b47a32951ad.webp","97aebd11-5fed-43e8-a64c-f99ebce112e1.webp"]	t	["XS","S","M","L"]	2023-03-04 12:58:14.052+00	2023-03-04 12:58:14.052+00	1	1
8	Find stunning women's cocktail dresses and party dresses. Stand out in lace and metallic cocktail dresses and party dresses from all your favorite brands.	419	WOMEN	["88f6bec9-f2a5-4d30-b22a-bec53eb022f0.webp","a98074d0-d3a5-4fe7-85b1-555f1f8928de.webp","5ef724fc-8a87-4b51-b749-a142f8c94771.webp","409adb34-5745-4b25-a895-ddcf83c24e34.webp"]	t	["XS","S","M","L"]	2023-03-04 12:58:27.015+00	2023-03-04 12:58:27.015+00	1	1
9	Find stunning women's cocktail dresses and party dresses. Stand out in lace and metallic cocktail dresses and party dresses from all your favorite brands.	429	WOMEN	["0372447f-814a-4ef2-9d33-893c5ef1e129.webp","3a427daa-d666-4054-8998-cb614ef4d049.webp","aaff1ec9-06cd-4aee-9060-799c9bb6fb90.webp","a5f68f22-3c2f-4c20-b4b0-e5f533f7bc3a.webp"]	t	["XS","S","M","L"]	2023-03-04 12:58:40.967+00	2023-03-04 12:58:40.967+00	1	1
10	Find stunning women's cocktail dresses and party dresses. Stand out in lace and metallic cocktail dresses and party dresses from all your favorite brands.	429	WOMEN	["3367e638-25ac-4b81-a008-5edcde80db55.webp","e585390c-82f6-4249-9614-5202af5e3458.webp","77b0e9fc-42ab-4668-b8d0-bbb2c76ebb29.webp"]	t	["XS","S","M","L"]	2023-03-04 12:58:52.855+00	2023-03-04 12:58:52.855+00	1	1
11	Find stunning women's cocktail dresses and party dresses. Stand out in lace and metallic cocktail dresses and party dresses from all your favorite brands.	449	WOMEN	["c8e6d638-9c50-44bd-aef1-29c2c1cb0147.webp","ab2db0d8-02fc-44ae-86a7-4af0798d5d1a.webp","ab003fbc-e08a-42c5-8536-04ce8321cb92.webp","b13e23ce-a552-4538-8062-cd5190de8107.webp"]	t	["XS","S","M","L"]	2023-03-04 12:59:10.722+00	2023-03-04 12:59:10.722+00	1	1
12	Find stunning women's cocktail dresses and party dresses. Stand out in lace and metallic cocktail dresses and party dresses from all your favorite brands.	429	WOMEN	["5863a06b-4ad4-4eb3-b4d9-07e92956e78c.webp","d5d3b93d-8e1c-4fa6-b56c-de6d4788ae6c.webp","af0d0792-b366-49a7-8796-59c5b2edcd42.webp"]	t	["XS","S","M","L"]	2023-03-04 12:59:23.644+00	2023-03-04 12:59:23.644+00	1	1
13	Find stunning women's cocktail dresses and party dresses. Stand out in lace and metallic cocktail dresses and party dresses from all your favorite brands.	429	WOMEN	["126bbcbe-8171-400e-bc2a-96a5479e29c2.webp","ccc34dde-da8c-497d-a43f-f18351ffc841.webp","35d9df32-699c-4639-9880-59a82a518c27.webp"]	t	["XS","S","M","L"]	2023-03-04 12:59:32.628+00	2023-03-04 12:59:32.628+00	1	1
14	Find stunning women's cocktail dresses and party dresses. Stand out in lace and metallic cocktail dresses and party dresses from all your favorite brands.	429	WOMEN	["65fb8aac-98ef-4e26-a0ae-0223f348f514.webp","1cc534a6-a7ad-42d8-ab15-bb4200f1ff95.webp","056e5a4e-e3a9-4aed-8f6f-820fce64126f.webp"]	t	["XS","S","M","L"]	2023-03-04 12:59:43.846+00	2023-03-04 12:59:43.846+00	1	1
15	Find stunning women's cocktail dresses and party dresses. Stand out in lace and metallic cocktail dresses and party dresses from all your favorite brands.	429	WOMEN	["1200ce9f-513b-4287-ba62-4c75b17b13d0.webp","b16fef7e-a0b2-44e2-8198-52399ff13af9.webp","7ee930dc-c929-458d-9ed2-b3b1312bed27.webp"]	t	["XS","S","M","L"]	2023-03-04 13:00:12.754+00	2023-03-04 13:00:12.754+00	1	1
16	Find stunning women's cocktail dresses and party dresses. Stand out in lace and metallic cocktail dresses and party dresses from all your favorite brands.	449	WOMEN	["868617f8-903c-468c-86f8-ba2cec85a698.webp","84d9534f-8596-4fda-89c1-c2e75fc80e0f.webp","68e0d539-977c-4f2a-bc43-48f9fef426e1.webp"]	t	["XS","S","M","L"]	2023-03-04 13:00:25.576+00	2023-03-04 13:00:25.576+00	1	1
17	Find stunning women's cocktail dresses and party dresses. Stand out in lace and metallic cocktail dresses and party dresses from all your favorite brands.	449	WOMEN	["c2cf99d7-aeff-4a60-b98f-80b54c420d83.webp","d9869fc1-4c43-4e5d-be94-fb1132385bc8.webp","947afe6d-188c-4b5d-808b-5e20d2ca48ff.webp","f175b880-88b1-4069-9f15-fd5bc80b6c10.webp"]	t	["XS","S","M","L"]	2023-03-04 13:00:36.724+00	2023-03-04 13:00:36.724+00	1	1
18	Find stunning women's cocktail dresses and party dresses. Stand out in lace and metallic cocktail dresses and party dresses from all your favorite brands.	449	WOMEN	["438f2ac9-3e5e-482b-bf2e-5309d523dc93.webp","633a2d79-eae0-4a15-9590-88b842ec9045.webp","f7b94abd-6e0c-4e02-a99d-3d860fa3234c.webp","0aa28090-3840-47e3-9973-ac563560f7da.webp"]	t	["XS","S","M","L"]	2023-03-04 13:00:47.004+00	2023-03-04 13:00:47.004+00	1	1
19	Find stunning women's cocktail dresses and party dresses. Stand out in lace and metallic cocktail dresses and party dresses from all your favorite brands.	449	WOMEN	["23391c17-6b69-4bd5-abb5-169852d9863b.webp","e066ff53-f988-478f-b1d2-ea1560beb2c3.webp","7db74598-557f-464f-a010-45b54772225c.webp","55fa1cfd-0942-47ed-b7a7-2742adf84eb8.webp"]	t	["XS","S","M","L"]	2023-03-04 13:00:59.342+00	2023-03-04 13:00:59.342+00	1	1
20	Find stunning women's cocktail dresses and party dresses. Stand out in lace and metallic cocktail dresses and party dresses from all your favorite brands.	399	WOMEN	["3c39356d-dbff-49e2-a96b-d0e19d9ff58b.webp","6ea9710f-646b-4aba-86dc-fad37274b1c9.webp","4440fd12-be7c-4076-8f28-03ba870b8f77.webp","3af1c1b8-e01b-4de8-8d7a-a7a9889dadc0.webp"]	t	["XS","S","M","L"]	2023-03-04 13:01:17.967+00	2023-03-04 13:01:17.967+00	1	1
21	Find stunning women's cocktail dresses and party dresses. Stand out in lace and metallic cocktail dresses and party dresses from all your favorite brands.	439	WOMEN	["b5113afe-9eb5-4153-b063-a1a32bfcfdca.webp","1b72524d-9ba4-41e2-88ac-3d7920a33672.webp"]	t	["XS","S","M","L"]	2023-03-04 13:01:34.629+00	2023-03-04 13:01:34.629+00	1	1
22	Find stunning women's cocktail dresses and party dresses. Stand out in lace and metallic cocktail dresses and party dresses from all your favorite brands.	429	WOMEN	["a191b244-ca12-4477-8d6c-a25d84549154.webp","970728e3-1e38-4109-9caf-51f0bf2bac52.webp","b1a9f303-4a75-4aa1-80b0-86dd6ad93d8a.webp","f193e7aa-7c34-467b-814b-87ee8dc0d2b3.webp"]	t	["XS","S","M","L"]	2023-03-04 13:01:48.917+00	2023-03-04 13:01:48.917+00	1	1
23	Find stunning women's cocktail dresses and party dresses. Stand out in lace and metallic cocktail dresses and party dresses from all your favorite brands.	439	WOMEN	["8d4c8a60-4dca-47d2-9353-44682d58e908.webp","acea8b6e-dcd8-49d4-8b5f-be5cf0009ec7.webp","785aec19-79ae-451b-ace4-8b6b0344bfa4.webp","00016004-e251-41bb-ab34-0bc1df3067a8.webp"]	t	["XS","S","M","L"]	2023-03-04 13:02:08.532+00	2023-03-04 13:02:08.532+00	1	1
24	Find stunning women's cocktail dresses and party dresses. Stand out in lace and metallic cocktail dresses and party dresses from all your favorite brands.	439	WOMEN	["72f62bbf-d2c9-4748-b339-0f8525b66751.webp","d899026a-f132-45b1-b38e-2956529d07fa.webp","d685f473-1cb5-4f80-8dd4-3bd4558bc5bc.webp","237e175e-b816-4848-9899-14e14dfe7724.webp"]	t	["XS","S","M","L"]	2023-03-04 13:02:19.42+00	2023-03-04 13:02:19.42+00	1	1
25	Find stunning women's cocktail dresses and party dresses. Stand out in lace and metallic cocktail dresses and party dresses from all your favorite brands.	439	WOMEN	["010b0500-6a4e-426d-99b4-78adf44a7c34.webp","87ce94ef-c26c-41ed-a325-e4b8cd5137ef.webp","c1439f34-71af-4030-b2e3-830294f4f976.webp","9b449b22-f416-454a-8c69-93a79e966e25.webp"]	t	["XS","S","M","L"]	2023-03-04 13:02:30.992+00	2023-03-04 13:02:30.992+00	1	1
26	Find stunning women's cocktail dresses and party dresses. Stand out in lace and metallic cocktail dresses and party dresses from all your favorite brands.	439	WOMEN	["8bcf81bd-5c5c-42a7-9990-bf5f2db2a19c.webp","d9f66e5f-b466-45e2-bc6f-a044527a7e9a.webp","85a693ed-6f9f-41d4-9b94-3ae1ce2743f2.webp","6a103f46-e84f-4108-93d1-130b2b2f3786.webp","60a5eca3-17b2-463e-98bf-696cb0e39e60.webp"]	t	["XS","S","M","L"]	2023-03-04 13:02:43.931+00	2023-03-04 13:02:43.931+00	1	1
27	Find stunning women's cocktail dresses and party dresses. Stand out in lace and metallic cocktail dresses and party dresses from all your favorite brands.	179	WOMEN	["a07cb3e8-59b9-4366-bc28-c8b63d2cd5e7.webp","66819b27-b6da-4896-85fd-0236d94b8000.webp","70391d71-9ed4-4553-9816-a7c9ae24e6f3.webp","0e529251-d512-4ae4-a6d4-594dace25643.webp"]	t	["XS","S","M","L"]	2023-03-04 13:03:11.477+00	2023-03-04 13:03:11.477+00	2	1
28	Find stunning women's cocktail dresses and party dresses. Stand out in lace and metallic cocktail dresses and party dresses from all your favorite brands.	449	WOMEN	["6fc06403-798b-4cf4-abf7-9db1f5357e7a.webp","d4257d55-e420-4b2a-a1d1-6010b8d2c89a.webp","f220ca9e-9fd4-45da-b5d5-73158b02d0ee.webp","31530d39-e173-4389-b40e-a8662820f46b.webp"]	f	["XS","S","M","L"]	2023-03-04 13:03:36.182+00	2023-03-04 13:03:36.182+00	1	1
29	Find stunning women's cocktail dresses and party dresses. Stand out in lace and metallic cocktail dresses and party dresses from all your favorite brands.	179	WOMEN	["0d1901b6-9d4c-4910-987e-0b6882cc67a0.webp","742053da-5f15-430e-8a7e-930d86484f84.webp","564bb73e-68c7-49da-a667-f50b5c7ea877.webp"]	t	["XS","S","M","L"]	2023-03-04 13:04:40.937+00	2023-03-04 13:04:40.937+00	2	1
30	Find stunning women's cocktail dresses and party dresses. Stand out in lace and metallic cocktail dresses and party dresses from all your favorite brands.	439	WOMEN	["26da75f7-c209-4285-8a5f-0cd42791b4d3.webp","ed2c31fa-ded2-4a7e-b030-fce9a59e503f.webp","62eeb8c2-7eb4-4253-98ba-e51a8c0161ab.webp"]	t	["XS","S","M","L"]	2023-03-04 13:05:02.636+00	2023-03-04 13:05:02.636+00	1	1
31	Find stunning women's cocktail dresses and party dresses. Stand out in lace and metallic cocktail dresses and party dresses from all your favorite brands.	439	WOMEN	["0cabdc18-fd07-474d-8669-3f94b0b14a8a.webp","b1f2f0f9-7ca0-4579-a683-80167a00b195.webp","8f54b894-784c-4483-91d9-6a77990bee96.webp","a0eb23fb-0067-40a9-89aa-0b14f9b3aab2.webp"]	t	["XS","S","M","L"]	2023-03-04 13:05:13.978+00	2023-03-04 13:05:13.978+00	1	1
32	Find stunning women's cocktail dresses and party dresses. Stand out in lace and metallic cocktail dresses and party dresses from all your favorite brands.	239	MEN	["b695ec89-5258-464c-8d53-d9bf28614cde.webp","7e48f839-0fac-45ae-8d5f-0e229388294d.webp","9d62cda1-607b-49e0-9890-d0ff0869c5be.webp","468d1d8c-5f6f-4868-800d-74ded4e0b1a8.webp"]	t	["XS","S","M","L"]	2023-03-04 13:06:12.686+00	2023-03-04 13:06:12.686+00	1	2
33	Find stunning women's cocktail dresses and party dresses. Stand out in lace and metallic cocktail dresses and party dresses from all your favorite brands.	219	MEN	["e185fc0e-5625-49cd-85c4-4d059348bad5.webp","d6b9631f-c8b3-4933-8e33-5740afe70d7c.webp","336164b8-e066-4199-b0ed-ffe6a2bc5019.webp","f86956cc-f5c2-4ff2-91d6-579c5e09c5cd.webp","abb61355-b3b7-42db-b999-f69a839d4f7d.webp"]	t	["XS","S","M","L"]	2023-03-04 13:06:28.312+00	2023-03-04 13:06:28.312+00	1	2
34	Find stunning women's cocktail dresses and party dresses. Stand out in lace and metallic cocktail dresses and party dresses from all your favorite brands.	319	MEN	["941a6865-c533-4d2c-9bb1-3e1c0da182e6.webp","b37f0c3c-1c89-4b18-984e-611a7df22f71.webp"]	t	["XS","S","M","L"]	2023-03-04 13:06:50.592+00	2023-03-04 13:06:50.592+00	1	2
35	Find stunning women's cocktail dresses and party dresses. Stand out in lace and metallic cocktail dresses and party dresses from all your favorite brands.	129	MEN	["6a929031-0594-4324-9663-8c4bb028597d.webp","e6c47e18-2f6d-4d07-92c1-069933030173.webp","c637caf8-a81a-44f4-8c50-9dc16907c04f.webp"]	t	["XS","S","M","L"]	2023-03-04 13:07:11.209+00	2023-03-04 13:07:11.209+00	2	2
36	Find stunning women's cocktail dresses and party dresses. Stand out in lace and metallic cocktail dresses and party dresses from all your favorite brands.	179	MEN	["47b48d1f-24f7-44af-8fe4-bcab37afd983.webp","3fd911fb-c062-4ebd-9572-3bd8eb431dff.webp","0f4c4faa-97fb-4e20-820e-6b3fc8ad113a.webp"]	t	["XS","S","M","L"]	2023-03-04 13:07:57.954+00	2023-03-04 13:07:57.954+00	2	2
37	Find stunning women's cocktail dresses and party dresses. Stand out in lace and metallic cocktail dresses and party dresses from all your favorite brands.	179	KIDS	["f14d94a7-539e-4fc0-a3d6-2579780352ed.webp","f56fb008-3044-4c92-a3c5-dac1f0057ec5.webp","8e194973-4950-4473-8e0a-53b007440c47.webp","8f8d79df-4745-4b19-beae-6c2fdd2e2dd5.webp"]	t	["XS","S","M","L"]	2023-03-04 13:08:48.733+00	2023-03-04 13:08:48.733+00	3	1
38	Find stunning women's cocktail dresses and party dresses. Stand out in lace and metallic cocktail dresses and party dresses from all your favorite brands.	189	KIDS	["4cb9db67-4eb7-4a62-9e9e-8c1c6cad0173.webp","adaa74cd-3a88-4fa1-b643-8f92f1d26fc4.webp","25a846e1-bf01-4202-9ae1-700a19f39264.webp"]	t	["XS","S","M","L"]	2023-03-04 13:10:08.791+00	2023-03-04 13:10:08.791+00	1	1
\.


--
-- Data for Name: products_colors; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.products_colors ("createdAt", "updatedAt", "ColorId", "ProductId") FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, email, password, role, "createdAt", "updatedAt") FROM stdin;
1	test@gmail.com	$2b$05$goXtlZEHIZZ/3PcbMwUZS.XHHNjqCe38bzgU9ouvGzwuY7DHFYJoW	USER	2023-02-10 16:41:20.864+00	2023-02-10 16:41:20.864+00
2	Tanuwa-Sun@yandex.ru	$2b$05$iaizlhiNDQSadnT3FQrBN.EGOMfntNq6x2k0jywUNXsx59qtEuHHG	USER	2023-02-14 09:35:03.826+00	2023-02-14 09:35:03.826+00
3	some@gmail.com	$2b$05$ReHNNmGut.D.gsByX1yyq.BqnccwZfw6lKyYqvmvktimLkMwvDyOa	USER	2023-02-16 18:32:17.725+00	2023-02-16 18:32:17.725+00
4	12623487632814276478@gmail.com	$2b$05$PEkpH/B43dwr90jx/jbYx.K1bVt7AeGARuo8P66H427glufAUC4oS	USER	2023-02-24 15:38:06.003+00	2023-02-24 15:38:06.003+00
5	demyan310505@gmail.com	$2b$05$sec/uisQ4SLneT4E4qwTdONd1y03ZF9TzWpd5zn1NA89A1wzW95Ha	USER	2023-03-04 12:37:35.048+00	2023-03-04 12:37:35.048+00
6	admin@gmail.com	$2b$05$.fZ1QnFq.xK9EJaIyCc27.zc8SkdIh6ylMetlgGetZ6jgBY31CtXC	ADMIN	2023-03-04 12:42:33.302+00	2023-03-04 12:42:33.302+00
7	dnetlyukh@gmail.com	$2b$05$Xjp9PXZWMNksi/j1ZnBW1.OJt1D9/2w6/679K4QkRM/SHlgkg1ZCm	USER	2023-03-04 13:10:54.925+00	2023-03-04 13:10:54.925+00
\.


--
-- Name: brands_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.brands_id_seq', 2, true);


--
-- Name: cart_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.cart_items_id_seq', 2, true);


--
-- Name: carts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.carts_id_seq', 7, true);


--
-- Name: categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.categories_id_seq', 3, true);


--
-- Name: colors_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.colors_id_seq', 1, false);


--
-- Name: products_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.products_id_seq', 38, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_id_seq', 7, true);


--
-- Name: brands brands_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.brands
    ADD CONSTRAINT brands_name_key UNIQUE (name);


--
-- Name: brands brands_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.brands
    ADD CONSTRAINT brands_pkey PRIMARY KEY (id);


--
-- Name: cart_items cart_items_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cart_items
    ADD CONSTRAINT cart_items_pkey PRIMARY KEY (id);


--
-- Name: carts carts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.carts
    ADD CONSTRAINT carts_pkey PRIMARY KEY (id);


--
-- Name: categories categories_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_name_key UNIQUE (name);


--
-- Name: categories categories_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_pkey PRIMARY KEY (id);


--
-- Name: colors colors_hex_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.colors
    ADD CONSTRAINT colors_hex_key UNIQUE (hex);


--
-- Name: colors colors_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.colors
    ADD CONSTRAINT colors_pkey PRIMARY KEY (id);


--
-- Name: products_colors products_colors_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.products_colors
    ADD CONSTRAINT products_colors_pkey PRIMARY KEY ("ColorId", "ProductId");


--
-- Name: products products_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_pkey PRIMARY KEY (id);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: cart_items cart_items_CartId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cart_items
    ADD CONSTRAINT "cart_items_CartId_fkey" FOREIGN KEY ("CartId") REFERENCES public.carts(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: cart_items cart_items_ProductId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cart_items
    ADD CONSTRAINT "cart_items_ProductId_fkey" FOREIGN KEY ("ProductId") REFERENCES public.products(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: carts carts_UserId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.carts
    ADD CONSTRAINT "carts_UserId_fkey" FOREIGN KEY ("UserId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: products products_BrandId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT "products_BrandId_fkey" FOREIGN KEY ("BrandId") REFERENCES public.brands(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: products products_CategoryId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT "products_CategoryId_fkey" FOREIGN KEY ("CategoryId") REFERENCES public.categories(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: products_colors products_colors_ColorId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.products_colors
    ADD CONSTRAINT "products_colors_ColorId_fkey" FOREIGN KEY ("ColorId") REFERENCES public.colors(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: products_colors products_colors_ProductId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.products_colors
    ADD CONSTRAINT "products_colors_ProductId_fkey" FOREIGN KEY ("ProductId") REFERENCES public.products(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

